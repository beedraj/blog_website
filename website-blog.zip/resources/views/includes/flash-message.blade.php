@if(session('status'))
                <p style="color:white;width:100%;font-size:18px;font-weight:600;text-align:center;background:green;padding:17px 0;margin-botton:6px;">
                {{session('status')}}</p>
            @endif