<p>Message</p>
<p>{{$data['message']}}</p>

<div style="margin-top:50px;">
<p>Name:{{$data['name']}}</p>
<p>Email:{{$data['email']}}</p>
</div>