

<?php $__env->startSection('main'); ?>
        <main class="container" style="background-color:#fff;">
        <section id="contact us">
            <h1 style="padding-top:50px;">Create New post</h1>

            <!-- contact form -->
            <div class="contacr form">
                <form action ="" method="">
                    <div>
                    <lable for="title"><span>Title</span></lable>
                    <input type="text" id="title" name="title"/>

                    </div>
                    
                    <div>
                    <lable for="image"><span>Image</span></lable>
                    <input type="file" id="image" name="image"/>

                    </div>
                    <div><lable for="body"><span>Body</span></lable>
                    <textarea id="body" name="body"></textarea>
                    </div>
                    <input type="submit" value="submit">
                </form>
            </div>
            </section>
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-blog\resources\views/create-blog-post.blade.php ENDPATH**/ ?>