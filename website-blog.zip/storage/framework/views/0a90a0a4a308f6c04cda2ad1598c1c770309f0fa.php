


<?php $__env->startSection('main'); ?>
        <main class="container" style="background-color:white;">
        <section id="contact us">
            <h1 style="padding-top:50px;">Create New Category</h1>
            <?php echo $__env->make('includes.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- contact form -->
            <div class="contacr form">
                <form action ="<?php echo e(route('categories.store')); ?>" method="Post"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <lable for="name"><span>Name</span></lable>
                    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>"/>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color:red;margin-bottom:25px;"><?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                   
                    
                  
                    <input type="submit" value="submit" >
                </form>
            </div>
            <div class= "create-categorie">
                <a href="<?php echo e(route('categories.index')); ?>">Categories list<span>&#8594;</span></a>
            </div>
            </section>
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-blog\resources\views/categories/create-category.blade.php ENDPATH**/ ?>