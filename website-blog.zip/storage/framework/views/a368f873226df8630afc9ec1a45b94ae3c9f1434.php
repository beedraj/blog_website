

<?php $__env->startSection('main'); ?>
    <!-- main -->
    <main class="container">
      <h2 class="header-title">All Blog Posts</h2>
      <?php echo $__env->make('includes.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="searchbar">
        <form action="">
          <input type="text" placeholder="Search..." name="search" />
          <button type="submit">
            <i class="fa fa-search"></i>
          </button>
        </form>
      </div>
      <div class="categories">
        <ul>
          
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(route('blog.index',['category'=>$category->name])); ?>"><?php echo e($category->name); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>

      <section class="cards-blog latest-blog">
        
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card-blog-content">
        <img src="<?php echo e(asset($post->imagePath)); ?>" alt="" />
          <?php if(auth()->guard()->check()): ?>
          <?php if(auth()->user()->id===$post->user->id): ?>

          <div class="post-buttons">
            <a href="<?php echo e(route('blog.edit',$post)); ?>">Edit</a>
            
           
            <form action="<?php echo e(route('blog-delete',$post)); ?>" method="Post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <input type="submit" value="Delete">
            </form>
          <?php endif; ?>
          <?php endif; ?>
          
          <p>
            
            <?php echo e($post->created_at->diffForHumans()); ?>

            <span>Written By <?php echo e($post->user->name); ?></span>
          </p>
          <h4>
            <a href="<?php echo e(route('blog.show',$post)); ?>"><?php echo e($post->title); ?></a>
          </h4>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Sorry, currently there is no blog post related to your search!</p>
        
        <?php endif; ?>

        

        
      </section>

      
      
    </main>

    <!-- pagination -->
    <!-- <div class="pagination" id="pagination">
          <a href="">&laquo;</a>
          <a class="active" href="">1</a>
          <a href="">2</a>
          <a href="">3</a>
          <a href="">4</a>
          <a href="">5</a>
          <a href="">&raquo;</a>
        </div>
        <br> -->
        <?php echo e($posts->links('pagination::default')); ?>

        <br>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-blog\resources\views/blogposts/blog.blade.php ENDPATH**/ ?>