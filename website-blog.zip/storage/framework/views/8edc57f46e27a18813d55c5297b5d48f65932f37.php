<?php if(session('status')): ?>
                <p style="color:white;width:100%;font-size:18px;font-weight:600;text-align:center;background:green;padding:17px 0;margin-botton:6px;">
                <?php echo e(session('status')); ?></p>
            <?php endif; ?><?php /**PATH C:\xampp\htdocs\website-blog\resources\views/includes/flash-message.blade.php ENDPATH**/ ?>